/* Erochat Stage 1 PWA Service Worker
 * Robust per-item caching under /erochat/ subpath:
 * One missing file will NEVER break cache installation.
 */
const CACHE_NAME = 'erochat-shell-v1';
const BASE_PATH = '/erochat/';

const PRECACHE_URLS = [
  BASE_PATH,
  BASE_PATH + 'index.html',
  BASE_PATH + 'manifest.webmanifest',
  BASE_PATH + 'icons/icon.svg',
  BASE_PATH + 'icons/icon-192.svg',
  BASE_PATH + 'icons/icon-512.svg',
  BASE_PATH + 'icons/icon-maskable.svg',
  './',
  './index.html',
  './manifest.webmanifest',
  './icons/icon.svg',
  './icons/icon-192.svg',
  './icons/icon-512.svg',
  './icons/icon-maskable.svg'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Cache each file individually so a missing asset never fails the whole install
      await Promise.allSettled(
        PRECACHE_URLS.map(async (url) => {
          try {
            const response = await fetch(url, { cache: 'no-cache' });
            if (response && response.ok) {
              await cache.put(url, response.clone());
            }
          } catch (_err) {
            // Ignore single-asset failure gracefully
          }
        })
      );
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
          return Promise.resolve();
        })
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  if (url.origin !== self.location.origin) return;

  // Navigation requests: network first, fallback to cached app shell
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const networkResponse = await fetch(request);
          if (networkResponse && networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone()).catch(() => {});
            return networkResponse;
          }
        } catch (_err) {
          // Offline fallback
        }
        const cache = await caches.open(CACHE_NAME);
        return (
          (await cache.match(request)) ||
          (await cache.match(BASE_PATH + 'index.html')) ||
          (await cache.match(BASE_PATH)) ||
          (await cache.match('./index.html')) ||
          (await cache.match('./')) ||
          new Response('Offline - Erochat Demo', {
            status: 503,
            headers: { 'Content-Type': 'text/plain; charset=utf-8' }
          })
        );
      })()
    );
    return;
  }

  // Static same-origin assets: stale-while-revalidate
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);

      const networkPromise = fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.ok) {
            cache.put(request, networkResponse.clone()).catch(() => {});
          }
          return networkResponse;
        })
        .catch(() => null);

      if (cached) {
        return cached;
      }
      const networkResponse = await networkPromise;
      if (networkResponse) {
        return networkResponse;
      }
      return new Response('', { status: 404 });
    })()
  );
});
