import React from 'react';

interface CompactLogoProps {
  size?: number;
  className?: string;
}

/**
 * Compact logo used in headers after the launch animation:
 * a real geometric "E" (vertical stem + three bars) with a blue middle bar,
 * so it reads as a letter and not as a menu icon.
 */
export const EroCompactLogo: React.FC<CompactLogoProps> = ({ size = 26, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ direction: 'ltr' }}
      aria-label="ERO Logo"
    >
      <rect x="24" y="27" width="28" height="10" fill="#287BFF" />
      <rect x="14" y="10" width="10" height="44" fill="#FFFFFF" />
      <rect x="14" y="10" width="38" height="10" fill="#FFFFFF" />
      <rect x="14" y="44" width="38" height="10" fill="#FFFFFF" />
    </svg>
  );
};

interface FullLogoProps {
  width?: number;
  className?: string;
}

/**
 * Full "ERO" logo: letters E, R, O joined by one blue line through the middle
 * that ends as a dot inside the O.
 */
export const EroFullGeometricLogo: React.FC<FullLogoProps> = ({ width = 180, className = '' }) => {
  const height = Math.round((width / 280) * 120);
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 280 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ direction: 'ltr' }}
      aria-label="ERO Geometric Logo"
    >
      <g transform="translate(73,30)">
        {/* Blue line through the middle of all three letters */}
        <rect x="10" y="25" width="106" height="10" fill="#287BFF" />
        <circle cx="116" cy="30" r="9" fill="#287BFF" />
        {/* E */}
        <rect x="0" y="0" width="10" height="60" fill="#FFFFFF" />
        <rect x="0" y="0" width="32" height="10" fill="#FFFFFF" />
        <rect x="0" y="50" width="32" height="10" fill="#FFFFFF" />
        {/* R */}
        <rect x="46" y="0" width="10" height="60" fill="#FFFFFF" />
        <rect x="46" y="0" width="36" height="10" fill="#FFFFFF" />
        <rect x="72" y="0" width="10" height="35" fill="#FFFFFF" />
        <polygon points="58,35 72,35 90,60 76,60" fill="#FFFFFF" />
        {/* O */}
        <rect x="98" y="0" width="10" height="60" fill="#FFFFFF" />
        <rect x="124" y="0" width="10" height="60" fill="#FFFFFF" />
        <rect x="98" y="0" width="36" height="10" fill="#FFFFFF" />
        <rect x="98" y="50" width="36" height="10" fill="#FFFFFF" />
      </g>
    </svg>
  );
};
