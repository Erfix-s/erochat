import React from 'react';

interface CompactLogoProps {
  size?: number;
  className?: string;
}

/**
 * Compact three-bar geometric E logo used in headers after the launch animation.
 */
export const EroCompactLogo: React.FC<CompactLogoProps> = ({ size = 26, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ direction: 'ltr' }}
      aria-label="ERO Logo"
    >
      <rect x="8" y="10" width="48" height="10" fill="#FFFFFF" />
      <rect x="8" y="27" width="48" height="10" fill="#FFFFFF" />
      <rect x="8" y="44" width="48" height="10" fill="#FFFFFF" />
    </svg>
  );
};

interface FullLogoProps {
  width?: number;
  className?: string;
}

/**
 * Static geometric "ERO" logo (E = 3 horizontal white bars; R and O = angular geometric letters with right sides cut)
 */
export const EroFullGeometricLogo: React.FC<FullLogoProps> = ({ width = 180, className = '' }) => {
  const height = Math.round((width / 280) * 120);
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 280 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ direction: 'ltr' }}
      aria-label="ERO Geometric Logo"
    >
      {/* E: Three horizontal white bars */}
      <g>
        <rect x="20" y="20" width="68" height="16" fill="#FFFFFF" />
        <rect x="20" y="52" width="68" height="16" fill="#FFFFFF" />
        <rect x="20" y="84" width="68" height="16" fill="#FFFFFF" />
      </g>
      {/* R: Angular geometric letter with right side cut */}
      <g>
        <polygon points="112,20 180,20 166,36 128,36 128,100 112,100" fill="#FFFFFF" />
        <polygon points="128,52 164,52 152,68 128,68" fill="#FFFFFF" />
        <polygon points="136,68 154,68 176,100 158,100" fill="#287BFF" />
      </g>
      {/* O: Angular geometric letter with right side cut */}
      <g>
        <polygon
          points="200,32 212,20 268,20 254,36 216,36 216,84 254,84 268,100 212,100 200,88"
          fill="#FFFFFF"
        />
        <polygon points="252,36 268,36 268,48 252,44" fill="#4694FF" />
        <polygon points="252,76 268,72 268,84 252,84" fill="#4694FF" />
      </g>
    </svg>
  );
};
