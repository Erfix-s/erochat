import React, { useState } from 'react';
import type { Chat, ChatType } from '../types';
import type { Translations } from '../locales/fa';
import { generateId } from '../utils/format';
import { IconClose, IconGroup } from './Icons';

interface NewChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateChat: (chat: Chat, initialMessageText: string) => void;
  t: Translations;
}

const AVATAR_SWATCHES = [
  { color: '#287BFF', accent: '#4694FF' },
  { color: '#1F56C3', accent: '#5D9EFF' },
  { color: '#3948B8', accent: '#7588FF' },
  { color: '#156A8A', accent: '#3CA8D1' },
  { color: '#5A3696', accent: '#9B6EE3' }
];

export const NewChatModal: React.FC<NewChatModalProps> = ({
  isOpen,
  onClose,
  onCreateChat,
  t
}) => {
  const [type, setType] = useState<ChatType>('private');
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [bio, setBio] = useState('');
  const [swatchIdx, setSwatchIdx] = useState(0);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) return;

    const cleanHandle =
      handle.trim().replace(/^@/, '') ||
      `demo_${Math.random().toString(36).slice(2, 7)}`;
    const swatch = AVATAR_SWATCHES[swatchIdx] ?? AVATAR_SWATCHES[0];
    const glyph = trimmedName.slice(0, 2).toUpperCase();

    const newChat: Chat = {
      id: generateId('chat'),
      type,
      title: `${trimmedName} (نمونه)`,
      titleEn: `${trimmedName} (Demo)`,
      handle: cleanHandle,
      avatarColor: swatch.color,
      avatarAccent: swatch.accent,
      avatarGlyph: glyph,
      bio: bio.trim() || t.newChatModal.bioPlaceholder,
      bioEn: bio.trim() || t.newChatModal.bioPlaceholder,
      membersCount: type === 'group' ? 5 : undefined,
      online: true,
      lastSeenFa: type === 'group' ? '۵ عضو نمونه' : 'آنلاین (نمونه)',
      lastSeenEn: type === 'group' ? '5 demo members' : 'online (demo)',
      unreadCount: 0,
      pinned: false,
      isDemo: true
    };

    onCreateChat(newChat, t.newChatModal.initialMessage);
    setName('');
    setHandle('');
    setBio('');
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-header">
          <div>
            <div className="modal-title-row">
              <h3>{t.newChatModal.title}</h3>
              <span className="demo-pill">{t.demoBadge}</span>
            </div>
            <p className="modal-subtitle">{t.newChatModal.subtitle}</p>
          </div>
          <button type="button" className="icon-btn" onClick={onClose}>
            <IconClose size={19} />
          </button>
        </header>

        <form className="modal-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">{t.newChatModal.typeLabel}</label>
            <div className="segmented-control">
              <button
                type="button"
                className={`segment-btn ${type === 'private' ? 'segment-btn--active' : ''}`}
                onClick={() => setType('private')}
              >
                {t.newChatModal.privateType}
              </button>
              <button
                type="button"
                className={`segment-btn ${type === 'group' ? 'segment-btn--active' : ''}`}
                onClick={() => setType('group')}
              >
                <IconGroup size={15} />
                <span>{t.newChatModal.groupType}</span>
              </button>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">{t.newChatModal.nameLabel}</label>
            <input
              type="text"
              className="form-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t.newChatModal.namePlaceholder}
              required
              autoFocus
            />
          </div>

          <div className="form-group">
            <label className="form-label">{t.newChatModal.handleLabel}</label>
            <input
              type="text"
              className="form-input"
              dir="ltr"
              value={handle}
              onChange={(e) => setHandle(e.target.value)}
              placeholder={t.newChatModal.handlePlaceholder}
            />
          </div>

          <div className="form-group">
            <label className="form-label">{t.newChatModal.bioLabel}</label>
            <input
              type="text"
              className="form-input"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder={t.newChatModal.bioPlaceholder}
            />
          </div>

          <div className="form-group">
            <label className="form-label">{t.newChatModal.colorLabel}</label>
            <div className="swatch-row">
              {AVATAR_SWATCHES.map((s, idx) => (
                <button
                  key={s.color}
                  type="button"
                  className={`swatch-btn ${swatchIdx === idx ? 'swatch-btn--active' : ''}`}
                  style={{
                    background: `linear-gradient(135deg, ${s.color}, ${s.accent})`
                  }}
                  onClick={() => setSwatchIdx(idx)}
                  aria-label={`Color ${idx + 1}`}
                />
              ))}
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="secondary-btn" onClick={onClose}>
              {t.cancel}
            </button>
            <button type="submit" className="primary-btn" disabled={!name.trim()}>
              {t.newChatModal.createBtn}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
