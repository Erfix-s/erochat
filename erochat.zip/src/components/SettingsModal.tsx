import React, { useEffect, useState } from 'react';
import type {
  AppSettings,
  Language,
  NetworkSimMode,
  OutboxQueueItem,
  UserProfile
} from '../types';
import type { Translations } from '../locales/fa';
import {
  canPromptInstall,
  isRunningStandalone,
  subscribePWAInstallState,
  triggerInstallPrompt
} from '../utils/pwa';
import { EroCompactLogo, EroFullGeometricLogo } from './EroLogo';
import {
  IconClose,
  IconDownload,
  IconRetry,
  MessageStatusIcon
} from './Icons';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (next: AppSettings) => void;
  profile: UserProfile;
  onUpdateProfile: (next: UserProfile) => void;
  outbox: OutboxQueueItem[];
  onRetryAllOutbox: () => void;
  onRetrySingleMessage: (msgId: string) => void;
  onResetDemoData: () => void;
  onDownloadProjectZip: () => void;
  t: Translations;
}

type SettingsTab = 'general' | 'profile' | 'offline' | 'about';

const PROFILE_COLORS = ['#287BFF', '#1E56C5', '#3B4CCA', '#156A8A', '#5A3696'];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  profile,
  onUpdateProfile,
  outbox,
  onRetryAllOutbox,
  onRetrySingleMessage,
  onResetDemoData,
  onDownloadProjectZip,
  t
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('general');
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [username, setUsername] = useState(profile.username);
  const [bio, setBio] = useState(profile.bio);
  const [avatarColor, setAvatarColor] = useState(profile.avatarColor);
  const [savedBanner, setSavedBanner] = useState(false);
  const [installAvailable, setInstallAvailable] = useState(canPromptInstall());
  const [standalone, setStandalone] = useState(isRunningStandalone());

  useEffect(() => {
    setDisplayName(profile.displayName);
    setUsername(profile.username);
    setBio(profile.bio);
    setAvatarColor(profile.avatarColor);
  }, [profile]);

  useEffect(() => {
    return subscribePWAInstallState(() => {
      setInstallAvailable(canPromptInstall());
      setStandalone(isRunningStandalone());
    });
  }, []);

  if (!isOpen) return null;

  const handleLanguageSwitch = (lang: Language) => {
    onUpdateSettings({ ...settings, language: lang });
  };

  const handleNetModeChange = (mode: NetworkSimMode) => {
    onUpdateSettings({ ...settings, networkSimMode: mode });
  };

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      displayName: displayName.trim() || profile.displayName,
      username: username.trim().replace(/^@/, '') || profile.username,
      bio: bio.trim(),
      avatarColor
    });
    setSavedBanner(true);
    window.setTimeout(() => setSavedBanner(false), 2400);
  };

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true">
      <div
        className="modal-card modal-card--lg"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="modal-header">
          <div className="sidebar-brand">
            <div className="sidebar-logo-box">
              <EroCompactLogo size={20} />
            </div>
            <div>
              <div className="modal-title-row">
                <h3>{t.settingsModal.title}</h3>
                <span className="demo-pill">{t.demoBadge}</span>
              </div>
              <p className="modal-subtitle">{t.appTagline}</p>
            </div>
          </div>
          <button type="button" className="icon-btn" onClick={onClose}>
            <IconClose size={19} />
          </button>
        </header>

        {/* Settings Navigation Tabs */}
        <nav className="modal-tabs" role="tablist">
          {(
            [
              ['general', t.settingsModal.tabs.general],
              ['profile', t.settingsModal.tabs.profile],
              ['offline', t.settingsModal.tabs.offline],
              ['about', t.settingsModal.tabs.about]
            ] as [SettingsTab, string][]
          ).map(([tabKey, label]) => (
            <button
              key={tabKey}
              type="button"
              role="tab"
              aria-selected={activeTab === tabKey}
              className={`modal-tab-btn ${
                activeTab === tabKey ? 'modal-tab-btn--active' : ''
              }`}
              onClick={() => setActiveTab(tabKey)}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="modal-body">
          {/* TAB 1: GENERAL & LANGUAGE */}
          {activeTab === 'general' && (
            <>
              <section className="settings-card">
                <h4>{t.settingsModal.languageTitle}</h4>
                <p>{t.settingsModal.languageDesc}</p>
                <div className="segmented-control">
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.language === 'fa' ? 'segment-btn--active' : ''
                    }`}
                    onClick={() => handleLanguageSwitch('fa')}
                  >
                    {t.settingsModal.langFa}
                  </button>
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.language === 'en' ? 'segment-btn--active' : ''
                    }`}
                    onClick={() => handleLanguageSwitch('en')}
                  >
                    {t.settingsModal.langEn}
                  </button>
                </div>
              </section>

              <section className="settings-card">
                <h4>{t.settingsModal.autoReplyTitle}</h4>
                <p>{t.settingsModal.autoReplyDesc}</p>
                <div className="segmented-control">
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.simulateAutoReply ? 'segment-btn--active' : ''
                    }`}
                    onClick={() =>
                      onUpdateSettings({ ...settings, simulateAutoReply: true })
                    }
                  >
                    {settings.language === 'fa' ? 'فعال (نمونه)' : 'Enabled (Demo)'}
                  </button>
                  <button
                    type="button"
                    className={`segment-btn ${
                      !settings.simulateAutoReply ? 'segment-btn--active' : ''
                    }`}
                    onClick={() =>
                      onUpdateSettings({ ...settings, simulateAutoReply: false })
                    }
                  >
                    {settings.language === 'fa' ? 'غیرفعال' : 'Disabled'}
                  </button>
                </div>
              </section>

              <section className="settings-card">
                <button
                  type="button"
                  className="danger-outline-btn"
                  onClick={() => {
                    if (window.confirm(t.settingsModal.resetConfirm)) {
                      onResetDemoData();
                      onClose();
                    }
                  }}
                >
                  {t.settingsModal.resetDemoBtn}
                </button>
              </section>
            </>
          )}

          {/* TAB 2: PROFILE */}
          {activeTab === 'profile' && (
            <form className="settings-card" onSubmit={handleProfileSave}>
              <h4>{t.settingsModal.profileTitle}</h4>

              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div
                  className="chat-avatar chat-avatar--lg"
                  style={{ backgroundColor: avatarColor }}
                >
                  <span className="chat-avatar-glyph">
                    {displayName.slice(0, 2).toUpperCase()}
                  </span>
                </div>
                <div>
                  <strong style={{ display: 'block', fontSize: '0.95rem' }}>
                    {displayName}
                  </strong>
                  <span
                    style={{ fontSize: '0.8rem', color: 'var(--accent-light)' }}
                    dir="ltr"
                  >
                    @{username}
                  </span>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">{t.settingsModal.displayName}</label>
                <input
                  type="text"
                  className="form-input"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">{t.settingsModal.username}</label>
                <input
                  type="text"
                  className="form-input"
                  dir="ltr"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">{t.settingsModal.bio}</label>
                <input
                  type="text"
                  className="form-input"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">{t.settingsModal.avatarColor}</label>
                <div className="swatch-row">
                  {PROFILE_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      className={`swatch-btn ${
                        avatarColor === c ? 'swatch-btn--active' : ''
                      }`}
                      style={{ backgroundColor: c }}
                      onClick={() => setAvatarColor(c)}
                    />
                  ))}
                </div>
              </div>

              {savedBanner && (
                <p style={{ color: '#2CC873', fontWeight: 600 }}>
                  {t.settingsModal.profileSaved}
                </p>
              )}

              <button type="submit" className="primary-btn">
                {t.settingsModal.saveProfile}
              </button>
            </form>
          )}

          {/* TAB 3: OFFLINE QUEUE & PWA */}
          {activeTab === 'offline' && (
            <>
              <section className="settings-card">
                <h4>{t.settingsModal.offlineSectionTitle}</h4>
                <p>{t.settingsModal.offlineSectionDesc}</p>
                <div className="segmented-control">
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.networkSimMode === 'online'
                        ? 'segment-btn--active'
                        : ''
                    }`}
                    onClick={() => handleNetModeChange('online')}
                  >
                    {t.settingsModal.modeOnline}
                  </button>
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.networkSimMode === 'offline'
                        ? 'segment-btn--active'
                        : ''
                    }`}
                    onClick={() => handleNetModeChange('offline')}
                  >
                    {t.settingsModal.modeOffline}
                  </button>
                  <button
                    type="button"
                    className={`segment-btn ${
                      settings.networkSimMode === 'fail'
                        ? 'segment-btn--active'
                        : ''
                    }`}
                    onClick={() => handleNetModeChange('fail')}
                  >
                    {t.settingsModal.modeFail}
                  </button>
                </div>
              </section>

              <section className="settings-card">
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 8
                  }}
                >
                  <h4>{t.settingsModal.outboxTitle}</h4>
                  {outbox.length > 0 && (
                    <button
                      type="button"
                      className="secondary-btn"
                      onClick={onRetryAllOutbox}
                    >
                      <IconRetry size={14} />
                      <span>{t.settingsModal.retryAllBtn}</span>
                    </button>
                  )}
                </div>

                {outbox.length === 0 ? (
                  <p>{t.settingsModal.outboxEmpty}</p>
                ) : (
                  <div className="outbox-queue-list">
                    {outbox.map((item) => (
                      <div key={item.id} className="outbox-queue-item">
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            minWidth: 0
                          }}
                        >
                          <MessageStatusIcon status={item.status} size={16} />
                          <span
                            style={{
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis'
                            }}
                          >
                            {item.text}
                          </span>
                        </div>
                        <button
                          type="button"
                          className="outbox-flush-btn"
                          onClick={() => onRetrySingleMessage(item.id)}
                        >
                          <IconRetry size={13} />
                          <span>{t.retrySend}</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="settings-card">
                <h4>{t.settingsModal.pwaInstallTitle}</h4>
                {standalone ? (
                  <p style={{ color: '#2CC873' }}>
                    {t.settingsModal.pwaInstalled}
                  </p>
                ) : (
                  <>
                    {installAvailable && (
                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => triggerInstallPrompt()}
                      >
                        {t.settingsModal.pwaInstallBtn}
                      </button>
                    )}
                    <p>• {t.settingsModal.pwaInstallGuideAndroid}</p>
                    <p>• {t.settingsModal.pwaInstallGuideIOS}</p>
                  </>
                )}
              </section>
            </>
          )}

          {/* TAB 4: ABOUT & DOWNLOAD PROJECT ZIP */}
          {activeTab === 'about' && (
            <>
              <section className="settings-card settings-card--accent">
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 10,
                    padding: '8px 0'
                  }}
                >
                  <EroFullGeometricLogo width={165} />
                  <strong>{t.settingsModal.aboutTitle}</strong>
                </div>

                <h4>{t.settingsModal.honestyHeading}</h4>
                <ul className="honesty-list">
                  {t.settingsModal.honestyPoints.map((pt, idx) => (
                    <li key={idx}>{pt}</li>
                  ))}
                </ul>
              </section>

              <section className="settings-card">
                <h4>{t.settingsModal.zipTitle}</h4>
                <p>{t.settingsModal.zipDesc}</p>
                <button
                  type="button"
                  className="primary-btn"
                  onClick={onDownloadProjectZip}
                >
                  <IconDownload size={18} />
                  <span>{t.settingsModal.downloadZipBtn}</span>
                </button>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
