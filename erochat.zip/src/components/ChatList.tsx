import React, { useMemo } from 'react';
import type {
  Chat,
  ChatFilter,
  DraftItem,
  Language,
  Message,
  NetworkSimMode,
  OutboxQueueItem
} from '../types';
import type { Translations } from '../locales/fa';
import { formatChatListTime, toLocaleDigits } from '../utils/format';
import { EroCompactLogo } from './EroLogo';
import {
  IconClose,
  IconCompose,
  IconGroup,
  IconPin,
  IconRetry,
  IconSearch,
  IconSettings,
  MessageStatusIcon
} from './Icons';

interface ChatListProps {
  chats: Chat[];
  messages: Message[];
  drafts: Record<string, DraftItem>;
  outbox: OutboxQueueItem[];
  activeChatId: string | null;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  filter: ChatFilter;
  onFilterChange: (f: ChatFilter) => void;
  onSelectChat: (chatId: string) => void;
  onOpenNewChat: () => void;
  onOpenSettings: () => void;
  lang: Language;
  t: Translations;
  isBrowserOnline: boolean;
  networkSimMode: NetworkSimMode;
  onCycleNetworkMode: () => void;
  onFlushQueue: () => void;
}

export const ChatList: React.FC<ChatListProps> = ({
  chats,
  messages,
  drafts,
  outbox,
  activeChatId,
  searchQuery,
  onSearchChange,
  filter,
  onFilterChange,
  onSelectChat,
  onOpenNewChat,
  onOpenSettings,
  lang,
  t,
  isBrowserOnline,
  networkSimMode,
  onCycleNetworkMode,
  onFlushQueue
}) => {
  // Compute last message per chat
  const lastMessageMap = useMemo(() => {
    const map: Record<string, Message | undefined> = {};
    for (const msg of messages) {
      const existing = map[msg.chatId];
      if (!existing || msg.createdAt >= existing.createdAt) {
        map[msg.chatId] = msg;
      }
    }
    return map;
  }, [messages]);

  // Unread totals per filter
  const filterCounts = useMemo(() => {
    let all = 0;
    let priv = 0;
    let grp = 0;
    for (const c of chats) {
      if (c.unreadCount > 0) {
        all += c.unreadCount;
        if (c.type === 'private') priv += c.unreadCount;
        if (c.type === 'group') grp += c.unreadCount;
      }
    }
    return { all, private: priv, group: grp };
  }, [chats]);

  // Filter and sort chats (pinned first, then latest activity)
  const filteredChats = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return chats
      .filter((chat) => {
        if (filter === 'private' && chat.type !== 'private') return false;
        if (filter === 'group' && chat.type !== 'group') return false;
        if (!q) return true;

        const titleMatch =
          chat.title.toLowerCase().includes(q) ||
          chat.titleEn.toLowerCase().includes(q) ||
          chat.handle.toLowerCase().includes(q);
        if (titleMatch) return true;

        // Also search in messages of this chat
        return messages.some(
          (m) => m.chatId === chat.id && m.text.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        const lastA = drafts[a.id]?.updatedAt ?? lastMessageMap[a.id]?.createdAt ?? 0;
        const lastB = drafts[b.id]?.updatedAt ?? lastMessageMap[b.id]?.createdAt ?? 0;
        return lastB - lastA;
      });
  }, [chats, filter, searchQuery, messages, drafts, lastMessageMap]);

  const queuedCount = outbox.filter((i) => i.status === 'queued').length;
  const failedCount = outbox.filter((i) => i.status === 'failed').length;
  const effectiveOffline = !isBrowserOnline || networkSimMode === 'offline';

  return (
    <aside className="chat-sidebar" aria-label={t.appName}>
      {/* Top App Header with Compact 3-Bar ERO Logo */}
      <header className="sidebar-header">
        <div className="sidebar-brand">
          <div className="sidebar-logo-box" title="ERO">
            <EroCompactLogo size={22} />
          </div>
          <div className="sidebar-brand-text">
            <div className="sidebar-title-row">
              <h1 className="sidebar-title">{t.appName}</h1>
              <span className="demo-pill">{t.demoBadge}</span>
            </div>
            <p className="sidebar-subtitle">{t.appTagline}</p>
          </div>
        </div>

        <div className="sidebar-header-actions">
          <button
            type="button"
            className={`net-sim-chip net-sim-chip--${effectiveOffline ? 'offline' : networkSimMode}`}
            onClick={onCycleNetworkMode}
            title={t.network.switchModeHint}
          >
            <span className="net-dot" />
            <span className="net-sim-label">
              {effectiveOffline
                ? t.offline
                : networkSimMode === 'fail'
                ? lang === 'fa'
                  ? 'شبیه‌ساز خطا'
                  : 'Fail Sim'
                : lang === 'fa'
                ? 'آنلاین'
                : 'Online'}
            </span>
          </button>

          <button
            type="button"
            className="icon-btn"
            onClick={onOpenSettings}
            aria-label={t.settings}
            title={t.settings}
          >
            <IconSettings size={20} />
          </button>
        </div>
      </header>

      {/* Persistent Outbox / Offline Banner */}
      {(effectiveOffline || queuedCount > 0 || failedCount > 0) && (
        <div
          className={`outbox-banner ${
            failedCount > 0
              ? 'outbox-banner--failed'
              : 'outbox-banner--queued'
          }`}
        >
          <div className="outbox-banner-info">
            <span className="outbox-banner-dot" />
            <span>
              {!isBrowserOnline
                ? t.network.browserOffline
                : effectiveOffline
                ? t.network.offlineMode
                : ''}
              {(queuedCount > 0 || failedCount > 0) && (
                <strong className="outbox-counts">
                  {' '}
                  {queuedCount > 0 &&
                    `${toLocaleDigits(queuedCount, lang)} ${t.network.queueCount}`}
                  {queuedCount > 0 && failedCount > 0 ? ' • ' : ''}
                  {failedCount > 0 &&
                    `${toLocaleDigits(failedCount, lang)} ${t.network.failedCount}`}
                </strong>
              )}
            </span>
          </div>
          {(queuedCount > 0 || failedCount > 0) && (
            <button
              type="button"
              className="outbox-flush-btn"
              onClick={onFlushQueue}
            >
              <IconRetry size={13} />
              <span>{t.network.flushNow}</span>
            </button>
          )}
        </div>
      )}

      {/* Search Bar */}
      <div className="sidebar-search-wrap">
        <div className="search-input-box">
          <span className="search-icon">
            <IconSearch size={17} />
          </span>
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="search-input"
            aria-label={t.searchPlaceholder}
          />
          {searchQuery && (
            <button
              type="button"
              className="search-clear-btn"
              onClick={() => onSearchChange('')}
              aria-label={t.clearSearch}
            >
              <IconClose size={15} />
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs: All / Private / Groups */}
      <nav className="chat-filter-tabs" role="tablist">
        {(['all', 'private', 'group'] as ChatFilter[]).map((tab) => {
          const isActive = filter === tab;
          const badgeCount = filterCounts[tab];
          const label =
            tab === 'all'
              ? t.filters.all
              : tab === 'private'
              ? t.filters.private
              : t.filters.group;

          return (
            <button
              key={tab}
              type="button"
              role="tab"
              aria-selected={isActive}
              className={`filter-tab ${isActive ? 'filter-tab--active' : ''}`}
              onClick={() => onFilterChange(tab)}
            >
              <span>{label}</span>
              {badgeCount > 0 && (
                <span className="filter-tab-badge">
                  {toLocaleDigits(badgeCount, lang)}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Chat List Items */}
      <div className="chat-list-scroll" role="list">
        {filteredChats.length === 0 ? (
          <div className="chat-list-empty">
            <p>{t.noChatsFound}</p>
          </div>
        ) : (
          filteredChats.map((chat) => {
            const isSelected = chat.id === activeChatId;
            const lastMsg = lastMessageMap[chat.id];
            const draft = drafts[chat.id];
            const displayTitle = lang === 'fa' ? chat.title : chat.titleEn;
            const timeStamp = draft?.updatedAt || lastMsg?.createdAt;

            return (
              <button
                key={chat.id}
                type="button"
                role="listitem"
                className={`chat-row ${isSelected ? 'chat-row--active' : ''}`}
                onClick={() => onSelectChat(chat.id)}
              >
                {/* SVG Geometric Avatar */}
                <div
                  className="chat-avatar"
                  style={{
                    background: `linear-gradient(135deg, ${chat.avatarColor}, ${chat.avatarAccent})`
                  }}
                >
                  <span className="chat-avatar-glyph">{chat.avatarGlyph}</span>
                  {chat.online && chat.type === 'private' && (
                    <span className="chat-online-dot" />
                  )}
                </div>

                {/* Content */}
                <div className="chat-row-body">
                  <div className="chat-row-top">
                    <div className="chat-row-title-wrap">
                      {chat.type === 'group' && (
                        <span className="chat-type-icon" title={t.filters.group}>
                          <IconGroup size={14} />
                        </span>
                      )}
                      <span className="chat-row-title">{displayTitle}</span>
                    </div>

                    <div className="chat-row-meta">
                      {lastMsg && lastMsg.senderId === 'me' && !draft && (
                        <MessageStatusIcon status={lastMsg.status} size={14} />
                      )}
                      {timeStamp && (
                        <span className="chat-row-time">
                          {formatChatListTime(timeStamp, lang)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="chat-row-bottom">
                    <div className="chat-row-preview">
                      {draft && draft.text.trim() ? (
                        <span className="chat-preview-draft">
                          <strong>{t.draftPrefix} </strong>
                          {draft.text}
                        </span>
                      ) : lastMsg ? (
                        <span
                          className={`chat-preview-text ${
                            lastMsg.status === 'failed'
                              ? 'chat-preview-text--failed'
                              : lastMsg.status === 'queued'
                              ? 'chat-preview-text--queued'
                              : ''
                          }`}
                        >
                          {lastMsg.senderId === 'me' ? (
                            <span className="chat-preview-sender">{t.youPrefix} </span>
                          ) : chat.type === 'group' && lastMsg.senderName ? (
                            <span className="chat-preview-sender">
                              {lang === 'fa'
                                ? lastMsg.senderName
                                : lastMsg.senderNameEn || lastMsg.senderName}
                              :{' '}
                            </span>
                          ) : null}
                          {lastMsg.text}
                        </span>
                      ) : (
                        <span className="chat-preview-text">
                          {t.demoChatLabel}
                        </span>
                      )}
                    </div>

                    <div className="chat-row-badges">
                      {chat.pinned && chat.unreadCount === 0 && (
                        <span className="chat-pin-icon">
                          <IconPin size={13} />
                        </span>
                      )}
                      {chat.unreadCount > 0 && (
                        <span className="unread-badge">
                          {toLocaleDigits(chat.unreadCount, lang)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Floating New Chat Button */}
      <button
        type="button"
        className="fab-new-chat"
        onClick={onOpenNewChat}
        aria-label={t.newChat}
        title={t.newChat}
      >
        <IconCompose size={21} />
        <span className="fab-label">{t.newChat}</span>
      </button>
    </aside>
  );
};
