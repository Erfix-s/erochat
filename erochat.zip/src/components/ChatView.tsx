import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { Chat, DraftItem, Language, Message } from '../types';
import type { Translations } from '../locales/fa';
import { formatTime, toLocaleDigits } from '../utils/format';
import { EroCompactLogo } from './EroLogo';
import {
  IconBack,
  IconClose,
  IconCopy,
  IconEdit,
  IconInfo,
  IconReply,
  IconRetry,
  IconSend,
  IconTrash,
  MessageStatusIcon
} from './Icons';

interface ChatViewProps {
  chat: Chat | null;
  messages: Message[];
  draft?: DraftItem;
  lang: Language;
  t: Translations;
  onBackMobile: () => void;
  onDraftChange: (chatId: string, text: string, replyToId?: string) => void;
  onSendMessage: (chatId: string, text: string, replyToId?: string) => void;
  onEditMessage: (messageId: string, newText: string) => void;
  onDeleteMessage: (messageId: string) => void;
  onRetryMessage: (messageId: string) => void;
  onMarkMessageFailed: (messageId: string) => void;
  onClearChatHistory: (chatId: string) => void;
  onMarkChatUnread: (chatId: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  chat,
  messages,
  draft,
  lang,
  t,
  onBackMobile,
  onDraftChange,
  onSendMessage,
  onEditMessage,
  onDeleteMessage,
  onRetryMessage,
  onMarkMessageFailed,
  onClearChatHistory,
  onMarkChatUnread
}) => {
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [editInputText, setEditInputText] = useState<string>('');
  const [selectedMsgId, setSelectedMsgId] = useState<string | null>(null);
  const [highlightedMsgId, setHighlightedMsgId] = useState<string | null>(null);
  const [showInfoDrawer, setShowInfoDrawer] = useState<boolean>(false);
  const [toastText, setToastText] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const chatMessages = useMemo(() => {
    if (!chat) return [];
    return messages.filter((m) => m.chatId === chat.id);
  }, [chat, messages]);

  const messageById = useMemo(() => {
    const map: Record<string, Message> = {};
    for (const m of chatMessages) {
      map[m.id] = m;
    }
    return map;
  }, [chatMessages]);

  // Reset local states on chat switch
  useEffect(() => {
    setEditingMessage(null);
    setEditInputText('');
    setSelectedMsgId(null);
    setShowInfoDrawer(false);
  }, [chat?.id]);

  // Scroll to bottom when message count increases
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat?.id, chatMessages.length]);

  const showToast = (msg: string) => {
    setToastText(msg);
    window.setTimeout(() => {
      setToastText((prev) => (prev === msg ? null : prev));
    }, 2200);
  };

  if (!chat) {
    return (
      <main className="chat-main chat-main--empty">
        <div className="empty-chat-card">
          <div className="empty-logo-circle">
            <EroCompactLogo size={38} />
          </div>
          <h2>{t.selectChatPrompt}</h2>
          <p>{t.selectChatSub}</p>
          <span className="demo-pill demo-pill--lg">{t.demoBadge}</span>
        </div>
      </main>
    );
  }

  const currentDraftText = draft?.text ?? '';
  const currentReplyId = draft?.replyToId;
  const repliedMessage = currentReplyId ? messageById[currentReplyId] : undefined;

  const displayTitle = lang === 'fa' ? chat.title : chat.titleEn;
  const displayBio = lang === 'fa' ? chat.bio : chat.bioEn;
  const displaySub =
    chat.type === 'group' && chat.membersCount
      ? `${toLocaleDigits(chat.membersCount, lang)} ${t.members}`
      : lang === 'fa'
      ? chat.lastSeenFa
      : chat.lastSeenEn;

  const handleInputChange = (val: string) => {
    if (editingMessage) {
      setEditInputText(val);
    } else {
      onDraftChange(chat.id, val, currentReplyId);
    }
  };

  const handleSetReply = (msg: Message) => {
    setEditingMessage(null);
    onDraftChange(chat.id, currentDraftText, msg.id);
    setSelectedMsgId(null);
    textareaRef.current?.focus();
  };

  const handleStartEdit = (msg: Message) => {
    setEditingMessage(msg);
    setEditInputText(msg.text);
    setSelectedMsgId(null);
    textareaRef.current?.focus();
  };

  const handleCancelBanner = () => {
    if (editingMessage) {
      setEditingMessage(null);
      setEditInputText('');
    } else if (currentReplyId) {
      onDraftChange(chat.id, currentDraftText, undefined);
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (editingMessage) {
      const trimmed = editInputText.trim();
      if (!trimmed) return;
      onEditMessage(editingMessage.id, trimmed);
      setEditingMessage(null);
      setEditInputText('');
      return;
    }

    const trimmed = currentDraftText.trim();
    if (!trimmed) return;
    onSendMessage(chat.id, trimmed, currentReplyId);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const scrollToMessage = (targetId: string) => {
    const el = document.getElementById(`msg-bubble-${targetId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setHighlightedMsgId(targetId);
      window.setTimeout(() => {
        setHighlightedMsgId((prev) => (prev === targetId ? null : prev));
      }, 1600);
    }
  };

  const handleCopyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Fallback copy
    }
    setSelectedMsgId(null);
    showToast(t.copied);
  };

  const handleDelete = (messageId: string) => {
    onDeleteMessage(messageId);
    if (editingMessage?.id === messageId) {
      setEditingMessage(null);
      setEditInputText('');
    }
    setSelectedMsgId(null);
    showToast(t.deletedMessageToast);
  };

  const activeInputValue = editingMessage ? editInputText : currentDraftText;

  return (
    <main className="chat-main">
      {/* Chat Screen Header with Compact Three-Bar Logo */}
      <header className="chat-header">
        <div className="chat-header-start">
          <button
            type="button"
            className="icon-btn mobile-back-btn"
            onClick={onBackMobile}
            aria-label="Back"
          >
            <IconBack size={20} />
          </button>

          <div className="header-compact-ero" title="ERO">
            <EroCompactLogo size={18} />
          </div>

          <div
            className="chat-avatar chat-avatar--sm"
            style={{
              background: `linear-gradient(135deg, ${chat.avatarColor}, ${chat.avatarAccent})`
            }}
          >
            <span className="chat-avatar-glyph">{chat.avatarGlyph}</span>
            {chat.online && chat.type === 'private' && (
              <span className="chat-online-dot" />
            )}
          </div>

          <div
            className="chat-header-meta"
            onClick={() => setShowInfoDrawer((v) => !v)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter') setShowInfoDrawer((v) => !v);
            }}
          >
            <div className="chat-header-title-row">
              <h2 className="chat-header-title">{displayTitle}</h2>
              <span className="demo-pill">{t.demoBadge}</span>
            </div>
            <p className="chat-header-sub">{displaySub}</p>
          </div>
        </div>

        <div className="chat-header-actions">
          <button
            type="button"
            className={`icon-btn ${showInfoDrawer ? 'icon-btn--active' : ''}`}
            onClick={() => setShowInfoDrawer((v) => !v)}
            aria-label={t.chatInfo.title}
            title={t.chatInfo.title}
          >
            <IconInfo size={20} />
          </button>
        </div>
      </header>

      <div className="chat-body-split">
        {/* Scrollable Message Stream */}
        <div className="messages-viewport" onClick={() => setSelectedMsgId(null)}>
          {/* Honesty / Stage 1 Demo Notice Banner */}
          <div className="demo-notice-card">
            <div className="demo-notice-head">
              <span className="demo-pill">{t.demoBadge}</span>
              <strong>{t.demoBannerTitle}</strong>
            </div>
            <p>{t.demoBannerDesc}</p>
          </div>

          {chatMessages.map((msg) => {
            const isOut = msg.senderId === 'me';
            const isSelected = selectedMsgId === msg.id;
            const isHighlighted = highlightedMsgId === msg.id;
            const quotedMsg = msg.replyToId ? messageById[msg.replyToId] : undefined;

            return (
              <div
                key={msg.id}
                id={`msg-bubble-${msg.id}`}
                className={`msg-row ${isOut ? 'msg-row--out' : 'msg-row--in'} ${
                  isHighlighted ? 'msg-row--highlight' : ''
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedMsgId((prev) => (prev === msg.id ? null : msg.id));
                }}
              >
                <div
                  className={`msg-bubble ${
                    isOut ? 'msg-bubble--out' : 'msg-bubble--in'
                  } ${msg.status === 'queued' ? 'msg-bubble--queued' : ''} ${
                    msg.status === 'failed' ? 'msg-bubble--failed' : ''
                  }`}
                >
                  {/* Group Sender Name */}
                  {!isOut && chat.type === 'group' && msg.senderName && (
                    <div
                      className="msg-sender-name"
                      style={{ color: msg.senderColor || '#4694FF' }}
                    >
                      {lang === 'fa'
                        ? msg.senderName
                        : msg.senderNameEn || msg.senderName}
                    </div>
                  )}

                  {/* Replied Message Quote */}
                  {quotedMsg && (
                    <div
                      className="msg-reply-quote"
                      onClick={(e) => {
                        e.stopPropagation();
                        scrollToMessage(quotedMsg.id);
                      }}
                    >
                      <span className="msg-reply-author">
                        {quotedMsg.senderId === 'me'
                          ? t.youPrefix.replace(':', '')
                          : lang === 'fa'
                          ? quotedMsg.senderName || displayTitle
                          : quotedMsg.senderNameEn ||
                            quotedMsg.senderName ||
                            displayTitle}
                      </span>
                      <span className="msg-reply-snippet">{quotedMsg.text}</span>
                    </div>
                  )}

                  {/* Message Text */}
                  <div className="msg-text">{msg.text}</div>

                  {/* Distinct Status Badges for Queued (Pending) vs Failed */}
                  {isOut && msg.status === 'queued' && (
                    <div className="msg-state-banner msg-state-banner--queued">
                      <MessageStatusIcon status="queued" size={14} />
                      <span>{t.status.queued}</span>
                    </div>
                  )}

                  {isOut && msg.status === 'failed' && (
                    <div className="msg-state-banner msg-state-banner--failed">
                      <div className="msg-failed-info">
                        <MessageStatusIcon status="failed" size={14} />
                        <span>{t.status.failed}</span>
                      </div>
                      <button
                        type="button"
                        className="msg-retry-inline-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRetryMessage(msg.id);
                        }}
                      >
                        <IconRetry size={13} />
                        <span>{t.retrySend}</span>
                      </button>
                    </div>
                  )}

                  {/* Footer Meta: Edited + Timestamp + Delivery Icon */}
                  <div className="msg-meta">
                    {msg.editedAt && (
                      <span className="msg-edited-label">{t.edited}</span>
                    )}
                    <span className="msg-time">
                      {formatTime(msg.createdAt, lang)}
                    </span>
                    {isOut && (
                      <span
                        className="msg-status-wrap"
                        title={t.status[msg.status]}
                      >
                        <MessageStatusIcon status={msg.status} size={15} />
                      </span>
                    )}
                  </div>

                  {/* Contextual Action Toolbar (Reply / Edit / Copy / Fail-or-Retry / Delete) */}
                  <div
                    className={`msg-actions-bar ${
                      isSelected ? 'msg-actions-bar--open' : ''
                    }`}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      className="msg-action-btn"
                      onClick={() => handleSetReply(msg)}
                      title={t.reply}
                    >
                      <IconReply size={14} />
                      <span>{t.reply}</span>
                    </button>

                    {isOut && (
                      <button
                        type="button"
                        className="msg-action-btn"
                        onClick={() => handleStartEdit(msg)}
                        title={t.edit}
                      >
                        <IconEdit size={14} />
                        <span>{t.edit}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      className="msg-action-btn"
                      onClick={() => handleCopyText(msg.text)}
                      title={t.copy}
                    >
                      <IconCopy size={14} />
                      <span>{t.copy}</span>
                    </button>

                    {isOut && msg.status !== 'failed' && (
                      <button
                        type="button"
                        className="msg-action-btn msg-action-btn--warn"
                        onClick={() => {
                          onMarkMessageFailed(msg.id);
                          setSelectedMsgId(null);
                        }}
                        title={t.simulateFail}
                      >
                        <span>{t.simulateFail}</span>
                      </button>
                    )}

                    {isOut && msg.status === 'failed' && (
                      <button
                        type="button"
                        className="msg-action-btn msg-action-btn--accent"
                        onClick={() => {
                          onRetryMessage(msg.id);
                          setSelectedMsgId(null);
                        }}
                        title={t.retrySend}
                      >
                        <IconRetry size={14} />
                        <span>{t.retrySend}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      className="msg-action-btn msg-action-btn--danger"
                      onClick={() => handleDelete(msg.id)}
                      title={t.delete}
                    >
                      <IconTrash size={14} />
                      <span>{t.delete}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Optional Chat Info Side Panel */}
        {showInfoDrawer && (
          <aside className="chat-info-drawer">
            <div className="chat-info-header">
              <h3>{t.chatInfo.title}</h3>
              <button
                type="button"
                className="icon-btn"
                onClick={() => setShowInfoDrawer(false)}
              >
                <IconClose size={18} />
              </button>
            </div>

            <div className="chat-info-profile">
              <div
                className="chat-avatar chat-avatar--lg"
                style={{
                  background: `linear-gradient(135deg, ${chat.avatarColor}, ${chat.avatarAccent})`
                }}
              >
                <span className="chat-avatar-glyph">{chat.avatarGlyph}</span>
              </div>
              <h4>{displayTitle}</h4>
              <span className="demo-pill">
                {chat.type === 'group'
                  ? t.chatInfo.typeGroup
                  : t.chatInfo.typePrivate}
              </span>
            </div>

            <div className="chat-info-list">
              <div className="chat-info-item">
                <span className="chat-info-label">{t.chatInfo.handle}</span>
                <span className="chat-info-val" dir="ltr">
                  @{chat.handle}
                </span>
              </div>
              <div className="chat-info-item">
                <span className="chat-info-label">{t.chatInfo.bio}</span>
                <p className="chat-info-val">{displayBio}</p>
              </div>
            </div>

            <div className="chat-info-actions">
              <button
                type="button"
                className="secondary-btn"
                onClick={() => {
                  onMarkChatUnread(chat.id);
                  setShowInfoDrawer(false);
                }}
              >
                {t.chatInfo.markUnread}
              </button>
              <button
                type="button"
                className="danger-outline-btn"
                onClick={() => {
                  onClearChatHistory(chat.id);
                  setShowInfoDrawer(false);
                }}
              >
                {t.chatInfo.clearHistory}
              </button>
            </div>
          </aside>
        )}
      </div>

      {/* Toast Notification */}
      {toastText && <div className="floating-toast">{toastText}</div>}

      {/* Composer Area */}
      <footer className="chat-composer-wrap">
        {/* Reply or Edit Preview Bar */}
        {(editingMessage || repliedMessage) && (
          <div className="composer-context-bar">
            <div className="composer-context-icon">
              {editingMessage ? <IconEdit size={16} /> : <IconReply size={16} />}
            </div>
            <div className="composer-context-text">
              <span className="composer-context-title">
                {editingMessage
                  ? t.editingMessage
                  : `${t.replyingTo} ${
                      repliedMessage?.senderId === 'me'
                        ? t.youPrefix.replace(':', '')
                        : lang === 'fa'
                        ? repliedMessage?.senderName || displayTitle
                        : repliedMessage?.senderNameEn ||
                          repliedMessage?.senderName ||
                          displayTitle
                    }`}
              </span>
              <span className="composer-context-snippet">
                {editingMessage ? editingMessage.text : repliedMessage?.text}
              </span>
            </div>
            <button
              type="button"
              className="icon-btn"
              onClick={handleCancelBanner}
              aria-label={t.cancel}
            >
              <IconClose size={16} />
            </button>
          </div>
        )}

        <form className="composer-form" onSubmit={handleSubmit}>
          <textarea
            ref={textareaRef}
            rows={1}
            value={activeInputValue}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={t.messagePlaceholder}
            className="composer-textarea"
            aria-label={t.messagePlaceholder}
          />
          <button
            type="submit"
            className="composer-send-btn"
            disabled={!activeInputValue.trim()}
            aria-label={editingMessage ? t.saveEdit : t.send}
            title={editingMessage ? t.saveEdit : t.send}
          >
            <IconSend size={19} />
          </button>
        </form>
      </footer>
    </main>
  );
};
