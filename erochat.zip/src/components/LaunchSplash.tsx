import React, { useEffect, useState } from 'react';

const SESSION_KEY = 'erochat_launch_anim_played_v1';

// Module-level singleton + sessionStorage guard that survives React 19 StrictMode double-invocation
function hasAlreadyPlayedThisSession(): boolean {
  try {
    return sessionStorage.getItem(SESSION_KEY) === '1';
  } catch {
    return false;
  }
}

function markPlayedThisSession(): void {
  try {
    sessionStorage.setItem(SESSION_KEY, '1');
  } catch {
    // Ignore storage restriction
  }
}

let sessionAnimationCompleted = hasAlreadyPlayedThisSession();

interface LaunchSplashProps {
  onFinish?: () => void;
}

export const LaunchSplash: React.FC<LaunchSplashProps> = ({ onFinish }) => {
  const [visible, setVisible] = useState<boolean>(() => !sessionAnimationCompleted);
  const [sliding, setSliding] = useState<boolean>(false);
  const [onlyThreeBars, setOnlyThreeBars] = useState<boolean>(false);

  useEffect(() => {
    if (sessionAnimationCompleted) {
      setVisible(false);
      return;
    }

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReducedMotion) {
      // Respect prefers-reduced-motion: show final 3-bar state briefly without motion, then close
      setOnlyThreeBars(true);
      const t = window.setTimeout(() => {
        sessionAnimationCompleted = true;
        markPlayedThisSession();
        setVisible(false);
        onFinish?.();
      }, 320);
      return () => window.clearTimeout(t);
    }

    // Step 1: Start horizontal slide of RO to the LEFT behind E foreground mask
    const startSlideTimer = window.setTimeout(() => {
      setSliding(true);
    }, 280);

    // Step 2: RO is now completely behind the three E bars; hold final state where only the 3 white bars remain
    const holdFinalTimer = window.setTimeout(() => {
      setOnlyThreeBars(true);
    }, 1250);

    // Step 3: Complete launch sequence and lock session guard
    const finishTimer = window.setTimeout(() => {
      sessionAnimationCompleted = true;
      markPlayedThisSession();
      setVisible(false);
      onFinish?.();
    }, 1720);

    return () => {
      window.clearTimeout(startSlideTimer);
      window.clearTimeout(holdFinalTimer);
      window.clearTimeout(finishTimer);
    };
  }, [onFinish]);

  if (!visible) return null;

  return (
    <div
      className="ero-launch-overlay"
      role="status"
      aria-label="Erochat Launching"
      dir="ltr"
    >
      <div className="ero-launch-stage">
        <svg
          viewBox="0 0 280 120"
          width="280"
          height="120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="ero-launch-svg"
          style={{ direction: 'ltr' }}
        >
          <defs>
            {/* Clip at the left edge of the E plate so RO never shows left of the E */}
            <clipPath id="ero-mask-window">
              <rect x="-4" y="-10" width="180" height="80" />
            </clipPath>
          </defs>

          <g transform="translate(73,30)">
            <g clipPath="url(#ero-mask-window)">
              {/* BACKGROUND LAYER: blue line + R + O.
                  Slides strictly horizontally to the LEFT behind the E foreground mask (no fade, no shrink). */}
              {!onlyThreeBars && (
                <g
                  className={
                    sliding
                      ? 'ero-ro-group ero-ro-group--slide-left'
                      : 'ero-ro-group'
                  }
                >
                  <rect x="32" y="25" width="84" height="10" fill="#287BFF" />
                  <circle cx="116" cy="30" r="9" fill="#287BFF" />
                  <rect x="46" y="0" width="10" height="60" fill="#FFFFFF" />
                  <rect x="46" y="0" width="36" height="10" fill="#FFFFFF" />
                  <rect x="72" y="0" width="10" height="35" fill="#FFFFFF" />
                  <polygon points="58,35 72,35 90,60 76,60" fill="#FFFFFF" />
                  <rect x="98" y="0" width="10" height="60" fill="#FFFFFF" />
                  <rect x="124" y="0" width="10" height="60" fill="#FFFFFF" />
                  <rect x="98" y="0" width="36" height="10" fill="#FFFFFF" />
                  <rect x="98" y="50" width="36" height="10" fill="#FFFFFF" />
                </g>
              )}

              {/* FOREGROUND MASK LAYER: opaque plate + the E (stem, top/bottom bars, blue middle bar) */}
              <g className="ero-e-foreground-mask">
                <rect x="-4" y="-6" width="36" height="72" fill="#08090D" />
                <rect x="10" y="25" width="22" height="10" fill="#287BFF" />
                <rect x="0" y="0" width="10" height="60" fill="#FFFFFF" />
                <rect x="0" y="0" width="32" height="10" fill="#FFFFFF" />
                <rect x="0" y="50" width="32" height="10" fill="#FFFFFF" />
              </g>
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
};
