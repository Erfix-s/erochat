import React, { useEffect, useState } from 'react';

const SESSION_KEY = 'erochat_launch_anim_played_v1';

// Module-level singleton + sessionStorage guard that survives React 19 StrictMode double-invocation
function hasAlreadyPlayedThisSession(): boolean {
  try {
    return sessionStorage.getItem(SESSION_KEY) === '1';
  } catch {
    return false;
  }
}

function markPlayedThisSession(): void {
  try {
    sessionStorage.setItem(SESSION_KEY, '1');
  } catch {
    // Ignore storage restriction
  }
}

let sessionAnimationCompleted = hasAlreadyPlayedThisSession();

interface LaunchSplashProps {
  onFinish?: () => void;
}

export const LaunchSplash: React.FC<LaunchSplashProps> = ({ onFinish }) => {
  const [visible, setVisible] = useState<boolean>(() => !sessionAnimationCompleted);
  const [sliding, setSliding] = useState<boolean>(false);
  const [onlyThreeBars, setOnlyThreeBars] = useState<boolean>(false);

  useEffect(() => {
    if (sessionAnimationCompleted) {
      setVisible(false);
      return;
    }

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReducedMotion) {
      // Respect prefers-reduced-motion: show final 3-bar state briefly without motion, then close
      setOnlyThreeBars(true);
      const t = window.setTimeout(() => {
        sessionAnimationCompleted = true;
        markPlayedThisSession();
        setVisible(false);
        onFinish?.();
      }, 320);
      return () => window.clearTimeout(t);
    }

    // Step 1: Start horizontal slide of RO to the LEFT behind E foreground mask
    const startSlideTimer = window.setTimeout(() => {
      setSliding(true);
    }, 280);

    // Step 2: RO is now completely behind the three E bars; hold final state where only the 3 white bars remain
    const holdFinalTimer = window.setTimeout(() => {
      setOnlyThreeBars(true);
    }, 1250);

    // Step 3: Complete launch sequence and lock session guard
    const finishTimer = window.setTimeout(() => {
      sessionAnimationCompleted = true;
      markPlayedThisSession();
      setVisible(false);
      onFinish?.();
    }, 1720);

    return () => {
      window.clearTimeout(startSlideTimer);
      window.clearTimeout(holdFinalTimer);
      window.clearTimeout(finishTimer);
    };
  }, [onFinish]);

  if (!visible) return null;

  return (
    <div
      className="ero-launch-overlay"
      role="status"
      aria-label="Erochat Launching"
      dir="ltr"
    >
      <div className="ero-launch-stage">
        <svg
          viewBox="0 0 280 120"
          width="280"
          height="120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="ero-launch-svg"
          style={{ direction: 'ltr' }}
        >
          <defs>
            {/* Clip boundary at left edge of E (x=20) so RO disappears behind the E bars and never exits left */}
            <clipPath id="ero-mask-window">
              <rect x="20" y="0" width="260" height="120" />
            </clipPath>
          </defs>

          <g clipPath="url(#ero-mask-window)">
            {/* BACKGROUND LAYER: Geometric R and O (right sides cut).
                Slides strictly horizontally to the LEFT behind the E foreground mask (no fade, no shrink). */}
            {!onlyThreeBars && (
              <g
                className={
                  sliding
                    ? 'ero-ro-group ero-ro-group--slide-left'
                    : 'ero-ro-group'
                }
              >
                {/* R: Angular geometric letter with right side cut */}
                <g>
                  <polygon
                    points="112,20 180,20 166,36 128,36 128,100 112,100"
                    fill="#FFFFFF"
                  />
                  <polygon
                    points="128,52 164,52 152,68 128,68"
                    fill="#FFFFFF"
                  />
                  <polygon
                    points="136,68 154,68 176,100 158,100"
                    fill="#FFFFFF"
                  />
                </g>

                {/* O: Angular geometric letter with right side cut */}
                <g>
                  <polygon
                    points="200,32 212,20 268,20 254,36 216,36 216,84 254,84 268,100 212,100 200,88"
                    fill="#FFFFFF"
                  />
                  <polygon
                    points="252,36 268,36 268,48 252,44"
                    fill="#FFFFFF"
                  />
                  <polygon
                    points="252,76 268,72 268,84 252,84"
                    fill="#FFFFFF"
                  />
                </g>
              </g>
            )}

            {/* FOREGROUND MASK LAYER: E column opaque #08090D mask + three horizontal white bars */}
            <g className="ero-e-foreground-mask">
              <rect x="18" y="12" width="72" height="96" fill="#08090D" />
              <rect x="20" y="20" width="68" height="16" fill="#FFFFFF" />
              <rect x="20" y="52" width="68" height="16" fill="#FFFFFF" />
              <rect x="20" y="84" width="68" height="16" fill="#FFFFFF" />
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
};
