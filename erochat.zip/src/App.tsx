import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChatList } from './components/ChatList';
import { ChatView } from './components/ChatView';
import { LaunchSplash } from './components/LaunchSplash';
import { NewChatModal } from './components/NewChatModal';
import { SettingsModal } from './components/SettingsModal';
import { en } from './locales/en';
import { fa } from './locales/fa';
import type {
  AppSettings,
  Chat,
  ChatFilter,
  DraftItem,
  Message,
  NetworkSimMode,
  OutboxQueueItem,
  UserProfile
} from './types';
import {
  deleteMessageFromDB,
  loadInitialData,
  removeOutboxItemFromDB,
  resetAllDemoDataInDB,
  saveChatToDB,
  saveDraftToDB,
  saveMessageToDB,
  saveOutboxItemToDB,
  saveProfileToDB,
  saveSettingsToDB
} from './utils/db';
import {
  DEFAULT_PROFILE,
  DEFAULT_SETTINGS,
  INITIAL_CHATS,
  INITIAL_DRAFTS,
  INITIAL_MESSAGES,
  getDemoReplyText
} from './utils/demoData';
import { generateId } from './utils/format';
import { initPWA } from './utils/pwa';
import { downloadErochatProjectZip } from './utils/zipBuilder';

export function App() {
  const [chats, setChats] = useState<Chat[]>(INITIAL_CHATS);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [drafts, setDrafts] = useState<Record<string, DraftItem>>(INITIAL_DRAFTS);
  const [outbox, setOutbox] = useState<OutboxQueueItem[]>([]);
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  const [activeChatId, setActiveChatId] = useState<string | null>('chat_ero_guide');
  const [mobileChatOpen, setMobileChatOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filter, setFilter] = useState<ChatFilter>('all');
  const [isNewChatOpen, setIsNewChatOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isBrowserOnline, setIsBrowserOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Initialize PWA service worker & install listeners once
  useEffect(() => {
    initPWA();
  }, []);

  // Load persisted data from IndexedDB on startup
  useEffect(() => {
    let mounted = true;
    loadInitialData().then((data) => {
      if (!mounted) return;
      setChats(data.chats);
      setMessages(data.messages);
      setDrafts(data.drafts);
      setOutbox(data.outbox);
      setProfile(data.profile);
      setSettings(data.settings);
    });
    return () => {
      mounted = false;
    };
  }, []);

  // Sync HTML lang and dir attributes whenever language changes
  useEffect(() => {
    const dir = settings.language === 'fa' ? 'rtl' : 'ltr';
    document.documentElement.lang = settings.language;
    document.documentElement.dir = dir;
  }, [settings.language]);

  // Listen to browser online/offline events
  useEffect(() => {
    const handleOnline = () => setIsBrowserOnline(true);
    const handleOffline = () => setIsBrowserOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const t = useMemo(() => (settings.language === 'fa' ? fa : en), [settings.language]);

  const activeChat = useMemo(
    () => chats.find((c) => c.id === activeChatId) ?? null,
    [chats, activeChatId]
  );

  // Helper to progress a message through sent -> delivered -> read and optional demo reply
  const simulateMessageDeliveryFlow = useCallback(
    (msg: Message, currentSettings: AppSettings, targetChat?: Chat) => {
      // Immediately mark as sent and remove from outbox queue
      const sentMsg: Message = { ...msg, status: 'sent' };
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? sentMsg : m)));
      saveMessageToDB(sentMsg);
      setOutbox((prev) => prev.filter((item) => item.id !== msg.id));
      removeOutboxItemFromDB(msg.id);

      // Step 2: Delivered
      window.setTimeout(() => {
        setMessages((prev) =>
          prev.map((m) => {
            if (m.id === msg.id && m.status === 'sent') {
              const updated: Message = { ...m, status: 'delivered' };
              saveMessageToDB(updated);
              return updated;
            }
            return m;
          })
        );
      }, 420);

      // Step 3: Read
      window.setTimeout(() => {
        setMessages((prev) =>
          prev.map((m) => {
            if (m.id === msg.id && (m.status === 'delivered' || m.status === 'sent')) {
              const updated: Message = { ...m, status: 'read' };
              saveMessageToDB(updated);
              return updated;
            }
            return m;
          })
        );
      }, 980);

      // Optional clearly labeled Demo Auto-Reply
      if (currentSettings.simulateAutoReply && targetChat) {
        window.setTimeout(() => {
          const replyMsg: Message = {
            id: generateId('msg_demo'),
            chatId: msg.chatId,
            senderId: `${msg.chatId}_peer`,
            senderName: targetChat.title,
            senderNameEn: targetChat.titleEn,
            senderColor: targetChat.avatarAccent,
            replyToId: msg.id,
            text: getDemoReplyText(
              msg.text,
              currentSettings.language,
              currentSettings.language === 'fa'
                ? targetChat.title
                : targetChat.titleEn
            ),
            createdAt: Date.now(),
            status: 'read',
            isDemo: true
          };
          setMessages((prev) => [...prev, replyMsg]);
          saveMessageToDB(replyMsg);
        }, 1500);
      }
    },
    []
  );

  // Automatically flush queued messages in outbox when returning online
  useEffect(() => {
    if (isBrowserOnline && settings.networkSimMode === 'online' && outbox.length > 0) {
      const queuedItems = outbox.filter((item) => item.status === 'queued');
      if (queuedItems.length === 0) return;

      queuedItems.forEach((item, idx) => {
        window.setTimeout(() => {
          const existingMsg = messages.find((m) => m.id === item.id);
          const chatObj = chats.find((c) => c.id === item.chatId);
          if (existingMsg) {
            simulateMessageDeliveryFlow(existingMsg, settings, chatObj);
          }
        }, idx * 240);
      });
    }
  }, [
    isBrowserOnline,
    settings.networkSimMode,
    outbox,
    messages,
    chats,
    settings,
    simulateMessageDeliveryFlow
  ]);

  // Select chat & clear unread count
  const handleSelectChat = (chatId: string) => {
    setActiveChatId(chatId);
    setMobileChatOpen(true);
    setChats((prev) =>
      prev.map((c) => {
        if (c.id === chatId && c.unreadCount > 0) {
          const updated = { ...c, unreadCount: 0 };
          saveChatToDB(updated);
          return updated;
        }
        return c;
      })
    );
  };

  // Update draft in memory and persist in IndexedDB
  const handleDraftChange = (chatId: string, text: string, replyToId?: string) => {
    setDrafts((prev) => {
      const next = { ...prev };
      if (!text.trim() && !replyToId) {
        delete next[chatId];
      } else {
        next[chatId] = {
          chatId,
          text,
          replyToId,
          updatedAt: Date.now()
        };
      }
      return next;
    });
    saveDraftToDB(chatId, text, replyToId);
  };

  // Send message (respecting online vs offline queue vs failure simulation)
  const handleSendMessage = (chatId: string, text: string, replyToId?: string) => {
    const now = Date.now();
    const msgId = generateId('msg');
    const effectiveOffline = !isBrowserOnline || settings.networkSimMode === 'offline';
    const shouldFail = settings.networkSimMode === 'fail';

    // Clear draft for this chat
    handleDraftChange(chatId, '', undefined);

    if (effectiveOffline) {
      const queuedMsg: Message = {
        id: msgId,
        chatId,
        senderId: 'me',
        text,
        replyToId,
        createdAt: now,
        status: 'queued',
        isDemo: true
      };
      const queueItem: OutboxQueueItem = {
        id: msgId,
        chatId,
        text,
        replyToId,
        createdAt: now,
        status: 'queued',
        attempts: 1
      };

      setMessages((prev) => [...prev, queuedMsg]);
      setOutbox((prev) => [...prev, queueItem]);
      saveMessageToDB(queuedMsg);
      saveOutboxItemToDB(queueItem);
      return;
    }

    if (shouldFail) {
      // First show queued briefly, then transition to failed in persistent outbox
      const initialMsg: Message = {
        id: msgId,
        chatId,
        senderId: 'me',
        text,
        replyToId,
        createdAt: now,
        status: 'queued',
        isDemo: true
      };
      setMessages((prev) => [...prev, initialMsg]);
      saveMessageToDB(initialMsg);

      window.setTimeout(() => {
        const failedMsg: Message = { ...initialMsg, status: 'failed' };
        const failedQueueItem: OutboxQueueItem = {
          id: msgId,
          chatId,
          text,
          replyToId,
          createdAt: now,
          status: 'failed',
          attempts: 1
        };
        setMessages((prev) => prev.map((m) => (m.id === msgId ? failedMsg : m)));
        setOutbox((prev) => [...prev.filter((i) => i.id !== msgId), failedQueueItem]);
        saveMessageToDB(failedMsg);
        saveOutboxItemToDB(failedQueueItem);
      }, 320);
      return;
    }

    // Online delivery flow
    const newMsg: Message = {
      id: msgId,
      chatId,
      senderId: 'me',
      text,
      replyToId,
      createdAt: now,
      status: 'sent',
      isDemo: true
    };
    setMessages((prev) => [...prev, newMsg]);
    saveMessageToDB(newMsg);

    const chatObj = chats.find((c) => c.id === chatId);
    simulateMessageDeliveryFlow(newMsg, settings, chatObj);
  };

  const handleEditMessage = (messageId: string, newText: string) => {
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === messageId) {
          const updated: Message = {
            ...m,
            text: newText,
            editedAt: Date.now()
          };
          saveMessageToDB(updated);
          return updated;
        }
        return m;
      })
    );
  };

  const handleDeleteMessage = (messageId: string) => {
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
    setOutbox((prev) => prev.filter((i) => i.id !== messageId));
    deleteMessageFromDB(messageId);
    removeOutboxItemFromDB(messageId);
  };

  const handleMarkMessageFailed = (messageId: string) => {
    const target = messages.find((m) => m.id === messageId);
    if (!target) return;
    const failedMsg: Message = { ...target, status: 'failed' };
    const queueItem: OutboxQueueItem = {
      id: target.id,
      chatId: target.chatId,
      text: target.text,
      replyToId: target.replyToId,
      createdAt: target.createdAt,
      status: 'failed',
      attempts: 1
    };
    setMessages((prev) => prev.map((m) => (m.id === messageId ? failedMsg : m)));
    setOutbox((prev) => [...prev.filter((i) => i.id !== messageId), queueItem]);
    saveMessageToDB(failedMsg);
    saveOutboxItemToDB(queueItem);
  };

  const handleRetryMessage = (messageId: string) => {
    const target = messages.find((m) => m.id === messageId);
    if (!target) return;

    // If user explicitly clicks Retry, switch out of fail mode to online so retry succeeds
    const nextSettings: AppSettings =
      settings.networkSimMode !== 'online'
        ? { ...settings, networkSimMode: 'online' }
        : settings;

    if (nextSettings !== settings) {
      setSettings(nextSettings);
      saveSettingsToDB(nextSettings);
    }

    const chatObj = chats.find((c) => c.id === target.chatId);
    simulateMessageDeliveryFlow(target, nextSettings, chatObj);
  };

  const handleFlushAllOutbox = () => {
    const nextSettings: AppSettings = { ...settings, networkSimMode: 'online' };
    setSettings(nextSettings);
    saveSettingsToDB(nextSettings);

    outbox.forEach((item, idx) => {
      window.setTimeout(() => {
        const msg = messages.find((m) => m.id === item.id);
        const chatObj = chats.find((c) => c.id === item.chatId);
        if (msg) {
          simulateMessageDeliveryFlow(msg, nextSettings, chatObj);
        }
      }, idx * 200);
    });
  };

  const handleCycleNetworkMode = () => {
    const order: NetworkSimMode[] = ['online', 'offline', 'fail'];
    const nextIdx = (order.indexOf(settings.networkSimMode) + 1) % order.length;
    const nextMode = order[nextIdx] ?? 'online';
    const updated: AppSettings = { ...settings, networkSimMode: nextMode };
    setSettings(updated);
    saveSettingsToDB(updated);
  };

  const handleCreateChat = (newChat: Chat, initialMessageText: string) => {
    const welcomeMsg: Message = {
      id: generateId('msg'),
      chatId: newChat.id,
      senderId: `${newChat.id}_system`,
      senderName: newChat.title,
      senderNameEn: newChat.titleEn,
      senderColor: newChat.avatarAccent,
      text: initialMessageText,
      createdAt: Date.now(),
      status: 'read',
      isDemo: true
    };
    setChats((prev) => [newChat, ...prev]);
    setMessages((prev) => [...prev, welcomeMsg]);
    saveChatToDB(newChat);
    saveMessageToDB(welcomeMsg);
    setActiveChatId(newChat.id);
    setMobileChatOpen(true);
  };

  const handleClearChatHistory = (chatId: string) => {
    const toRemove = messages.filter((m) => m.chatId === chatId);
    setMessages((prev) => prev.filter((m) => m.chatId !== chatId));
    toRemove.forEach((m) => {
      deleteMessageFromDB(m.id);
      removeOutboxItemFromDB(m.id);
    });
    setOutbox((prev) => prev.filter((i) => i.chatId !== chatId));
  };

  const handleMarkChatUnread = (chatId: string) => {
    setChats((prev) =>
      prev.map((c) => {
        if (c.id === chatId) {
          const updated = { ...c, unreadCount: Math.max(1, c.unreadCount + 1) };
          saveChatToDB(updated);
          return updated;
        }
        return c;
      })
    );
    setMobileChatOpen(false);
  };

  const handleUpdateSettings = (next: AppSettings) => {
    setSettings(next);
    saveSettingsToDB(next);
  };

  const handleUpdateProfile = (next: UserProfile) => {
    setProfile(next);
    saveProfileToDB(next);
  };

  const handleResetDemoData = async () => {
    const fresh = await resetAllDemoDataInDB();
    setChats(fresh.chats);
    setMessages(fresh.messages);
    setDrafts(fresh.drafts);
    setOutbox(fresh.outbox);
    setProfile(fresh.profile);
    setSettings(fresh.settings);
    setActiveChatId('chat_ero_guide');
  };

  return (
    <div
      className={`erochat-shell ${
        mobileChatOpen ? 'erochat-shell--chat-open' : ''
      }`}
      dir={settings.language === 'fa' ? 'rtl' : 'ltr'}
    >
      {/* Fresh-Launch-Only Geometric ERO Animation (Once per Session, StrictMode-Safe) */}
      <LaunchSplash />

      {/* Sidebar: Chat List, Search, Filters, New Chat Button */}
      <ChatList
        chats={chats}
        messages={messages}
        drafts={drafts}
        outbox={outbox}
        activeChatId={activeChatId}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        filter={filter}
        onFilterChange={setFilter}
        onSelectChat={handleSelectChat}
        onOpenNewChat={() => setIsNewChatOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        lang={settings.language}
        t={t}
        isBrowserOnline={isBrowserOnline}
        networkSimMode={settings.networkSimMode}
        onCycleNetworkMode={handleCycleNetworkMode}
        onFlushQueue={handleFlushAllOutbox}
      />

      {/* Main Conversation View */}
      <ChatView
        chat={activeChat}
        messages={messages}
        draft={activeChatId ? drafts[activeChatId] : undefined}
        lang={settings.language}
        t={t}
        onBackMobile={() => setMobileChatOpen(false)}
        onDraftChange={handleDraftChange}
        onSendMessage={handleSendMessage}
        onEditMessage={handleEditMessage}
        onDeleteMessage={handleDeleteMessage}
        onRetryMessage={handleRetryMessage}
        onMarkMessageFailed={handleMarkMessageFailed}
        onClearChatHistory={handleClearChatHistory}
        onMarkChatUnread={handleMarkChatUnread}
      />

      {/* New Demo Chat Modal */}
      <NewChatModal
        isOpen={isNewChatOpen}
        onClose={() => setIsNewChatOpen(false)}
        onCreateChat={handleCreateChat}
        t={t}
      />

      {/* Settings Modal (Language, Profile, Offline Queue & PWA, About & GitHub ZIP) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        outbox={outbox}
        onRetryAllOutbox={handleFlushAllOutbox}
        onRetrySingleMessage={handleRetryMessage}
        onResetDemoData={handleResetDemoData}
        onDownloadProjectZip={() => downloadErochatProjectZip()}
        t={t}
      />
    </div>
  );
}

export default App;
