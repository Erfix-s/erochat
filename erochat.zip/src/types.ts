export type Language = 'fa' | 'en';

export type ChatType = 'private' | 'group';

export type ChatFilter = 'all' | 'private' | 'group';

export type MessageStatus = 'queued' | 'sent' | 'delivered' | 'read' | 'failed';

export type NetworkSimMode = 'online' | 'offline' | 'fail';

export interface Message {
  id: string;
  chatId: string;
  senderId: 'me' | string;
  senderName?: string;
  senderNameEn?: string;
  senderColor?: string;
  text: string;
  createdAt: number;
  editedAt?: number;
  replyToId?: string;
  status: MessageStatus;
  isDemo?: boolean;
}

export interface Chat {
  id: string;
  type: ChatType;
  title: string;
  titleEn: string;
  handle: string;
  avatarColor: string;
  avatarAccent: string;
  avatarGlyph: string;
  bio: string;
  bioEn: string;
  membersCount?: number;
  online?: boolean;
  lastSeenFa: string;
  lastSeenEn: string;
  unreadCount: number;
  pinned?: boolean;
  muted?: boolean;
  isDemo: boolean;
}

export interface OutboxQueueItem {
  id: string; // matches message.id
  chatId: string;
  text: string;
  replyToId?: string;
  createdAt: number;
  status: 'queued' | 'failed';
  attempts: number;
}

export interface DraftItem {
  chatId: string;
  text: string;
  replyToId?: string;
  updatedAt: number;
}

export interface UserProfile {
  displayName: string;
  username: string;
  bio: string;
  avatarColor: string;
}

export interface AppSettings {
  language: Language;
  simulateAutoReply: boolean;
  networkSimMode: NetworkSimMode;
}
