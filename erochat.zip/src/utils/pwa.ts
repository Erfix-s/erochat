export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

let deferredPrompt: BeforeInstallPromptEvent | null = null;
const listeners = new Set<() => void>();

function notifyListeners() {
  listeners.forEach((fn) => fn());
}

/**
 * Generates crisp 192x192 and 512x512 PNG data URLs at runtime via Canvas
 * for iOS Safari apple-touch-icon and Android PNG compatibility,
 * keeping zero binary image files in the repository.
 */
function ensurePngCompatibleTouchIcons(): void {
  if (typeof document === 'undefined') return;
  try {
    const createIconDataUrl = (size: number): string => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (!ctx) return '';

      // Dark #08090D rounded background
      ctx.fillStyle = '#08090D';
      ctx.fillRect(0, 0, size, size);

      // Inner #11131A panel
      const pad = Math.round(size * 0.06);
      ctx.fillStyle = '#11131A';
      ctx.fillRect(pad, pad, size - pad * 2, size - pad * 2);

      // Subtle #287BFF frame border
      ctx.strokeStyle = 'rgba(40, 123, 255, 0.45)';
      ctx.lineWidth = Math.max(2, Math.round(size * 0.015));
      ctx.strokeRect(pad, pad, size - pad * 2, size - pad * 2);

      // Geometric E three white horizontal bars
      const x = Math.round(size * 0.26);
      const w = Math.round(size * 0.48);
      const h = Math.round(size * 0.095);
      const y1 = Math.round(size * 0.28);
      const y2 = Math.round(size * 0.452);
      const y3 = Math.round(size * 0.625);

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(x, y1, w, h);
      ctx.fillRect(x, y2, w, h);
      ctx.fillRect(x, y3, Math.round(w * 0.76), h);

      // Accent geometric cut on the bottom bar right
      ctx.fillStyle = '#287BFF';
      ctx.fillRect(x + Math.round(w * 0.8), y3, Math.round(w * 0.2), h);

      return canvas.toDataURL('image/png');
    };

    const png192 = createIconDataUrl(192);
    if (png192) {
      let appleLink = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
      if (!appleLink) {
        appleLink = document.createElement('link');
        appleLink.rel = 'apple-touch-icon';
        document.head.appendChild(appleLink);
      }
      appleLink.href = png192;
    }
  } catch {
    // Ignore canvas errors in restricted environments
  }
}

export function initPWA(): void {
  if (typeof window === 'undefined') return;

  ensurePngCompatibleTouchIcons();

  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    deferredPrompt = e as BeforeInstallPromptEvent;
    notifyListeners();
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    notifyListeners();
  });

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
      // Respect "/erochat/" subpath on GitHub Pages while supporting local preview
      const pathname = window.location.pathname;
      const isUnderErochat = pathname.startsWith('/erochat/') || pathname === '/erochat';
      const swUrl = isUnderErochat ? '/erochat/sw.js' : './sw.js';
      const scope = isUnderErochat ? '/erochat/' : './';

      try {
        await navigator.serviceWorker.register(swUrl, { scope });
      } catch {
        try {
          await navigator.serviceWorker.register('./sw.js');
        } catch {
          // Ignore SW registration failure in sandboxed iframes
        }
      }
    });
  }
}

export function canPromptInstall(): boolean {
  return deferredPrompt !== null;
}

export function isRunningStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

export async function triggerInstallPrompt(): Promise<boolean> {
  if (!deferredPrompt) return false;
  try {
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    deferredPrompt = null;
    notifyListeners();
    return choice.outcome === 'accepted';
  } catch {
    return false;
  }
}

export function subscribePWAInstallState(callback: () => void): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}
