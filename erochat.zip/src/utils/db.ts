import type { AppSettings, Chat, DraftItem, Message, OutboxQueueItem, UserProfile } from '../types';
import {
  DEFAULT_PROFILE,
  DEFAULT_SETTINGS,
  INITIAL_CHATS,
  INITIAL_DRAFTS,
  INITIAL_MESSAGES
} from './demoData';

const DB_NAME = 'erochat_stage1_db';
const DB_VERSION = 1;

const STORE_CHATS = 'chats';
const STORE_MESSAGES = 'messages';
const STORE_DRAFTS = 'drafts';
const STORE_OUTBOX = 'outbox';
const STORE_META = 'meta';

let dbPromise: Promise<IDBDatabase | null> | null = null;

function openDatabase(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') {
    return Promise.resolve(null);
  }
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve) => {
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_CHATS)) {
          db.createObjectStore(STORE_CHATS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
          db.createObjectStore(STORE_MESSAGES, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_DRAFTS)) {
          db.createObjectStore(STORE_DRAFTS, { keyPath: 'chatId' });
        }
        if (!db.objectStoreNames.contains(STORE_OUTBOX)) {
          db.createObjectStore(STORE_OUTBOX, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_META)) {
          db.createObjectStore(STORE_META, { keyPath: 'key' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });

  return dbPromise;
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openDatabase();
  if (!db) return [];
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve((req.result as T[]) || []);
      req.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

async function putInStore<T>(storeName: string, value: T): Promise<void> {
  const db = await openDatabase();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

async function deleteFromStore(storeName: string, key: string): Promise<void> {
  const db = await openDatabase();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

async function clearStore(storeName: string): Promise<void> {
  const db = await openDatabase();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

async function getMeta<T>(key: string): Promise<T | null> {
  const db = await openDatabase();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_META, 'readonly');
      const store = tx.objectStore(STORE_META);
      const req = store.get(key);
      req.onsuccess = () => {
        const res = req.result as { key: string; value: T } | undefined;
        resolve(res ? res.value : null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function setMeta<T>(key: string, value: T): Promise<void> {
  await putInStore(STORE_META, { key, value });
}

export interface InitialAppData {
  chats: Chat[];
  messages: Message[];
  drafts: Record<string, DraftItem>;
  outbox: OutboxQueueItem[];
  profile: UserProfile;
  settings: AppSettings;
}

export async function loadInitialData(): Promise<InitialAppData> {
  const seeded = await getMeta<boolean>('seeded_v1');

  if (!seeded) {
    for (const chat of INITIAL_CHATS) {
      await putInStore(STORE_CHATS, chat);
    }
    for (const msg of INITIAL_MESSAGES) {
      await putInStore(STORE_MESSAGES, msg);
    }
    for (const draft of Object.values(INITIAL_DRAFTS)) {
      await putInStore(STORE_DRAFTS, draft);
    }
    await setMeta('profile', DEFAULT_PROFILE);
    await setMeta('settings', DEFAULT_SETTINGS);
    await setMeta('seeded_v1', true);

    return {
      chats: INITIAL_CHATS,
      messages: INITIAL_MESSAGES,
      drafts: { ...INITIAL_DRAFTS },
      outbox: [],
      profile: DEFAULT_PROFILE,
      settings: DEFAULT_SETTINGS
    };
  }

  const [chats, messages, draftList, outbox, profile, settings] = await Promise.all([
    getAllFromStore<Chat>(STORE_CHATS),
    getAllFromStore<Message>(STORE_MESSAGES),
    getAllFromStore<DraftItem>(STORE_DRAFTS),
    getAllFromStore<OutboxQueueItem>(STORE_OUTBOX),
    getMeta<UserProfile>('profile'),
    getMeta<AppSettings>('settings')
  ]);

  const draftsMap: Record<string, DraftItem> = {};
  for (const d of draftList) {
    if (d.text.trim()) {
      draftsMap[d.chatId] = d;
    }
  }

  messages.sort((a, b) => a.createdAt - b.createdAt);
  outbox.sort((a, b) => a.createdAt - b.createdAt);

  return {
    chats: chats.length > 0 ? chats : INITIAL_CHATS,
    messages: messages.length > 0 ? messages : INITIAL_MESSAGES,
    drafts: draftsMap,
    outbox,
    profile: profile || DEFAULT_PROFILE,
    settings: settings || DEFAULT_SETTINGS
  };
}

export async function saveChatToDB(chat: Chat): Promise<void> {
  await putInStore(STORE_CHATS, chat);
}

export async function saveMessageToDB(message: Message): Promise<void> {
  await putInStore(STORE_MESSAGES, message);
}

export async function deleteMessageFromDB(messageId: string): Promise<void> {
  await deleteFromStore(STORE_MESSAGES, messageId);
}

export async function saveDraftToDB(chatId: string, text: string, replyToId?: string): Promise<void> {
  if (!text.trim() && !replyToId) {
    await deleteFromStore(STORE_DRAFTS, chatId);
    return;
  }
  const item: DraftItem = {
    chatId,
    text,
    replyToId,
    updatedAt: Date.now()
  };
  await putInStore(STORE_DRAFTS, item);
}

export async function saveOutboxItemToDB(item: OutboxQueueItem): Promise<void> {
  await putInStore(STORE_OUTBOX, item);
}

export async function removeOutboxItemFromDB(id: string): Promise<void> {
  await deleteFromStore(STORE_OUTBOX, id);
}

export async function saveProfileToDB(profile: UserProfile): Promise<void> {
  await setMeta('profile', profile);
}

export async function saveSettingsToDB(settings: AppSettings): Promise<void> {
  await setMeta('settings', settings);
}

export async function resetAllDemoDataInDB(): Promise<InitialAppData> {
  await Promise.all([
    clearStore(STORE_CHATS),
    clearStore(STORE_MESSAGES),
    clearStore(STORE_DRAFTS),
    clearStore(STORE_OUTBOX),
    clearStore(STORE_META)
  ]);
  return loadInitialData();
}
