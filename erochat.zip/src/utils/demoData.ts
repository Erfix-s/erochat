import type { AppSettings, Chat, DraftItem, Message, UserProfile } from '../types';

const now = Date.now();
const min = 60 * 1000;
const hour = 60 * min;

export const DEFAULT_PROFILE: UserProfile = {
  displayName: 'کاربر آزمایشی ایروچت (Demo)',
  username: 'ero_demo_user',
  bio: 'نسخه نمایشی مرحله ۱ ایروچت — ذخیره محلی در مرورگر (IndexedDB)',
  avatarColor: '#287BFF'
};

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'fa',
  simulateAutoReply: true,
  networkSimMode: 'online'
};

export const INITIAL_CHATS: Chat[] = [
  {
    id: 'chat_ero_guide',
    type: 'private',
    title: 'راهنمای ایروچت (نمونه / Demo)',
    titleEn: 'Erochat Guide (Demo)',
    handle: 'erochat_demo_bot',
    avatarColor: '#287BFF',
    avatarAccent: '#4694FF',
    avatarGlyph: 'ERO',
    bio: 'ربات راهنمای محلی مرحله ۱ (نمونه / بدون اتصال به سرور)',
    bioEn: 'Stage 1 Local Guide Bot (Frontend-only Demo)',
    online: true,
    lastSeenFa: 'ربات نمایشی آفلاین',
    lastSeenEn: 'local demo assistant',
    unreadCount: 1,
    pinned: true,
    isDemo: true
  },
  {
    id: 'chat_dev_group',
    type: 'group',
    title: 'انجمن طراحی رابط کاربری (نمونه)',
    titleEn: 'UI Design Guild (Demo Group)',
    handle: 'ero_ui_guild',
    avatarColor: '#1E64D8',
    avatarAccent: '#58A6FF',
    avatarGlyph: 'UI',
    bio: 'گروه نمونه برای تست پیام‌های گروهی، پاسخ، ویرایش و صف آفلاین IndexedDB',
    bioEn: 'Sample group for testing group bubbles, replies, edits, and IndexedDB offline queue',
    membersCount: 48,
    online: true,
    lastSeenFa: '۴۸ عضو نمونه',
    lastSeenEn: '48 demo members',
    unreadCount: 2,
    pinned: true,
    isDemo: true
  },
  {
    id: 'chat_kiarash',
    type: 'private',
    title: 'کیارش راد (مخاطب نمونه)',
    titleEn: 'Kiarash Rad (Demo Contact)',
    handle: 'kiarash_demo',
    avatarColor: '#2458B8',
    avatarAccent: '#4694FF',
    avatarGlyph: 'ک',
    bio: 'توسعه‌دهنده وب و علاقه‌مند به PWA (پروفایل نمونه)',
    bioEn: 'Frontend engineer & PWA enthusiast (Demo Profile)',
    online: true,
    lastSeenFa: 'آنلاین (نمونه)',
    lastSeenEn: 'online (demo)',
    unreadCount: 0,
    pinned: false,
    isDemo: true
  },
  {
    id: 'chat_nazanin',
    type: 'private',
    title: 'نازنین فرهمند (نمونه)',
    titleEn: 'Nazanin Farahmand (Demo)',
    handle: 'nazanin_ux',
    avatarColor: '#3B4CCA',
    avatarAccent: '#7085FF',
    avatarGlyph: 'ن',
    bio: 'طراح تجربه کاربری — داده‌های آزمایشی مرحله ۱',
    bioEn: 'Product Designer — Stage 1 Demo Data',
    online: false,
    lastSeenFa: 'آخرین بازدید اخیراً (نمونه)',
    lastSeenEn: 'last seen recently (demo)',
    unreadCount: 0,
    pinned: false,
    isDemo: true
  },
  {
    id: 'chat_pwa_group',
    type: 'group',
    title: 'گروه آزمایش آفلاین و PWA (نمونه)',
    titleEn: 'Offline & PWA Lab (Demo Group)',
    handle: 'pwa_offline_lab',
    avatarColor: '#164B9A',
    avatarAccent: '#4694FF',
    avatarGlyph: 'PWA',
    bio: 'محیط تست پیش‌نویس خودکار (Drafts) و صف پیام‌های آفلاین',
    bioEn: 'Testbed for IndexedDB auto-drafts and persistent outgoing message queue',
    membersCount: 19,
    online: false,
    lastSeenFa: '۱۹ عضو نمونه',
    lastSeenEn: '19 demo members',
    unreadCount: 0,
    pinned: false,
    isDemo: true
  }
];

export const INITIAL_MESSAGES: Message[] = [
  // Guide chat
  {
    id: 'm_guide_1',
    chatId: 'chat_ero_guide',
    senderId: 'ero_bot',
    senderName: 'راهنمای ایروچت (نمونه)',
    senderNameEn: 'Erochat Guide (Demo)',
    senderColor: '#4694FF',
    text: 'به «ایروچت» (Erochat — مرحله ۱: نسخه نمایشی) خوش آمدید! 👋\nاین برنامه یک وب‌اپلیکیشن قابل نصب (PWA) و کاملاً آفلاین است که بدون هیچ سرور یا سرویس خارجی در مرورگر شما اجرا می‌شود.',
    createdAt: now - 3 * hour,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_guide_2',
    chatId: 'chat_ero_guide',
    senderId: 'me',
    text: 'چه قابلیت‌هایی را می‌توانم در این نسخه نمایشی (Demo) امتحان کنم؟',
    createdAt: now - 2.8 * hour,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_guide_3',
    chatId: 'chat_ero_guide',
    senderId: 'ero_bot',
    senderName: 'راهنمای ایروچت (نمونه)',
    senderNameEn: 'Erochat Guide (Demo)',
    senderColor: '#4694FF',
    replyToId: 'm_guide_2',
    text: '۱. ارسال پیام، پاسخ (Reply)، ویرایش (Edit) و حذف (Delete) پیام‌ها.\n۲. ذخیره خودکار پیش‌نویس (Draft) در IndexedDB به محض تایپ کردن.\n۳. تغییر حالت شبکه در نوار بالا به «آفلاین» یا «خطا» برای مشاهده تفاوت ظاهری پیام‌های در صف انتظار (Pending/Queued) و ناموفق (Failed) به همراه دکمه تلاش مجدد (Retry).\n۴. تغییر زبان بین فارسی (RTL) و انگلیسی (LTR) از بخش تنظیمات.',
    createdAt: now - 2.5 * hour,
    status: 'read',
    isDemo: true
  },

  // UI Group chat
  {
    id: 'm_grp_1',
    chatId: 'chat_dev_group',
    senderId: 'arman',
    senderName: 'آرمان (نمونه)',
    senderNameEn: 'Arman (Demo)',
    senderColor: '#4694FF',
    text: 'دوستان رنگ‌بندی تاریک با پس‌زمینه #08090D و پنل #11131A روی نمایشگرهای OLED گوشی عالی دیده می‌شود.',
    createdAt: now - 5 * hour,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_grp_2',
    chatId: 'chat_dev_group',
    senderId: 'me',
    replyToId: 'm_grp_1',
    text: 'بله، کنتراست رنگ آبی #287BFF و #4694FF هم خوانایی حباب پیام‌ها را خیلی بالا برده است.',
    createdAt: now - 4.5 * hour,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_grp_3',
    chatId: 'chat_dev_group',
    senderId: 'sara',
    senderName: 'سارا (نمونه)',
    senderNameEn: 'Sara (Demo)',
    senderColor: '#6EA8FF',
    text: 'انیمیشن لوگوی هندسی ERO در شروع برنامه هم دقیقاً یک بار در هر نشست اجرا می‌شود و سه خط افقی سفید باقی می‌ماند.',
    createdAt: now - 45 * min,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_grp_4',
    chatId: 'chat_dev_group',
    senderId: 'arman',
    senderName: 'آرمان (نمونه)',
    senderNameEn: 'Arman (Demo)',
    senderColor: '#4694FF',
    replyToId: 'm_grp_3',
    text: 'حالت نصب PWA در مسیر /erochat/ گیت‌هاب پیجز هم تست شد و بدون هیچ خطایی کش آفلاین را می‌سازد. (پیام نمونه)',
    createdAt: now - 18 * min,
    status: 'read',
    isDemo: true
  },

  // Kiarash chat
  {
    id: 'm_kia_1',
    chatId: 'chat_kiarash',
    senderId: 'kiarash',
    senderName: 'کیارش راد (نمونه)',
    senderNameEn: 'Kiarash Rad (Demo)',
    text: 'سلام! اگر اینترنت گوشی قطع باشد، پیام‌هایی که می‌فرستی چه وضعیتی پیدا می‌کنند؟ (گفتگوی نمونه)',
    createdAt: now - 6 * hour,
    status: 'read',
    isDemo: true
  },
  {
    id: 'm_kia_2',
    chatId: 'chat_kiarash',
    senderId: 'me',
    replyToId: 'm_kia_1',
    text: 'وارد صف پایدار IndexedDB می‌شوند با نشانگر ساعت نارنجی (در صف ارسال)، و به محض وصل شدن شبکه خودکار ارسال می‌شوند!',
    createdAt: now - 5.8 * hour,
    editedAt: now - 5.7 * hour,
    status: 'delivered',
    isDemo: true
  },

  // Nazanin chat
  {
    id: 'm_naz_1',
    chatId: 'chat_nazanin',
    senderId: 'nazanin',
    senderName: 'نازنین فرهمند (نمونه)',
    senderNameEn: 'Nazanin Farahmand (Demo)',
    text: 'پیش‌نویس این گفتگو در IndexedDB ذخیره شده است؛ می‌توانی ادامه متن را در کادر پایین ببینی و ویرایش کنی.',
    createdAt: now - 12 * hour,
    status: 'read',
    isDemo: true
  },

  // PWA Lab group
  {
    id: 'm_pwa_1',
    chatId: 'chat_pwa_group',
    senderId: 'system_demo',
    senderName: 'آزمایشگاه PWA (نمونه)',
    senderNameEn: 'PWA Lab (Demo)',
    senderColor: '#4694FF',
    text: 'در این گروه می‌توانید دکمه وضعیت شبکه در بالا را روی «آفلاین» یا «خطای ارسال» بگذارید و تفاوت ظاهری پیام در صف (Pending) و پیام ناموفق (Failed) را بررسی کنید.',
    createdAt: now - 20 * hour,
    status: 'read',
    isDemo: true
  }
];

export const INITIAL_DRAFTS: Record<string, DraftItem> = {
  chat_nazanin: {
    chatId: 'chat_nazanin',
    text: 'سلام نازنین، این یک پیش‌نویس نمونه ذخیره‌شده در IndexedDB است...',
    updatedAt: now - 30 * min
  }
};

export function getDemoReplyText(userText: string, lang: 'fa' | 'en', chatTitle: string): string {
  const snippet = userText.length > 36 ? userText.slice(0, 36) + '…' : userText;
  if (lang === 'fa') {
    return `[پاسخ خودکار نمونه / Demo در «${chatTitle}»]\nپیام شما («${snippet}») در حافظه محلی مرورگر ثبت شد. توجه: این نسخه مرحله ۱ و بدون سرور است.`;
  }
  return `[Simulated Demo Reply in "${chatTitle}"]\nYour message ("${snippet}") was recorded locally in IndexedDB. Note: Stage 1 has no backend server.`;
}
