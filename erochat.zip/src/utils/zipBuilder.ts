export function downloadErochatProjectZip(): void {}
