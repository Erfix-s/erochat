import type { Language } from '../types';

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toLocaleDigits(value: string | number, lang: Language): string {
  const str = String(value);
  if (lang !== 'fa') return str;
  return str.replace(/\d/g, (d) => PERSIAN_DIGITS[Number(d)] ?? d);
}

export function formatTime(timestamp: number, lang: Language): string {
  const date = new Date(timestamp);
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return toLocaleDigits(`${hours}:${minutes}`, lang);
}

export function formatChatListTime(timestamp: number, lang: Language): string {
  const now = Date.now();
  const diff = now - timestamp;
  const oneDay = 24 * 60 * 60 * 1000;

  if (diff < oneDay) {
    return formatTime(timestamp, lang);
  }
  if (diff < 2 * oneDay) {
    return lang === 'fa' ? 'دیروز' : 'Yesterday';
  }
  const date = new Date(timestamp);
  const month = date.getMonth() + 1;
  const day = date.getDate();
  return toLocaleDigits(`${month}/${day}`, lang);
}

export function generateId(prefix = 'msg'): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
